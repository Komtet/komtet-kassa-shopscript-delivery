<?php
class shopKomtetdeliveryModel extends waModel
{
    protected $table = 'shop_komtetdelivery';
}
