<?php

return array(

    'komtetdelivery/<order_id>/' => array(
        'plugin' => 'komtetdelivery',
        'module' => 'frontend',
    ),
);
